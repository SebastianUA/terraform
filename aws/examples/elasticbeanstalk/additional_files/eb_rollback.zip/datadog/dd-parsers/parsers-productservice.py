from datadog import statsd


def parse_log(logger, line):
    if "SOURCE_TO_SEND" in line:
        # Split the line into fields
        duration = line.split('duration":')[-1]
        duration = duration.strip()
        print(duration)

        # build tags array
        attr_arr = []

        # sending metrics
        statsd.histogram("nps_messageprocessor_duration", duration, tags=attr_arr)
    else:
        return None