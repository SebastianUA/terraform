import requests
import json
from decimal import Decimal
from datadog import initialize, api
import argparse

options = {'api_key': '{{ env.DD_API_KEY }}',
         'app_key': '{{ env.DD_APP_KEY }}'}
initialize(**options)


r = requests.get("http://localhost/cache/stats")
response = r.json()
for cache in response['stats']:
  cacheName = cache['cachename']
  hitcount = cache['hitcount']
  misscount = cache["misscount"]
  api.Metric.send(
      metric='nps_productservice_cachemiss',
      points=misscount,
      tags=["cache:"+cacheName]
  )
  api.Metric.send(
      metric='nps_productservice_cachehit',
      points=hitcount,
      tags=["cache:"+cacheName]
    )